-- Create table to store crop dataset
CREATE TABLE public.crop_dataset (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nitrogen REAL NOT NULL,
  phosphorus REAL NOT NULL,
  potassium REAL NOT NULL,
  temperature REAL NOT NULL,
  humidity REAL NOT NULL,
  ph REAL NOT NULL,
  rainfall REAL NOT NULL,
  crop_label TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster ML queries
CREATE INDEX idx_crop_dataset_features ON public.crop_dataset (nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall);
CREATE INDEX idx_crop_dataset_label ON public.crop_dataset (crop_label);

-- Enable Row Level Security
ALTER TABLE public.crop_dataset ENABLE ROW LEVEL SECURITY;

-- Policy to allow reading for everyone (needed for ML predictions)
CREATE POLICY "Allow read access to crop dataset" 
ON public.crop_dataset 
FOR SELECT 
USING (true);

-- Create table for market prices
CREATE TABLE public.market_prices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  crop_name TEXT NOT NULL,
  price_per_kg REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  market_location TEXT,
  price_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for market prices
ALTER TABLE public.market_prices ENABLE ROW LEVEL SECURITY;

-- Policy to allow reading market prices
CREATE POLICY "Allow read access to market prices" 
ON public.market_prices 
FOR SELECT 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
NEW.updated_at = now();
RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_market_prices_updated_at
BEFORE UPDATE ON public.market_prices
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();