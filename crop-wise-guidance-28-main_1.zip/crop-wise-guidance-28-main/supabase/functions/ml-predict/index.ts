import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CropInput {
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  temperature: number;
  humidity: number;
  ph: number;
  rainfall: number;
}

interface CropRecommendation {
  crop: string;
  confidence: number;
  reason: string;
  marketPrice?: number;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { input } = await req.json() as { input: CropInput };

    console.log('Received prediction request:', input);

    // Get all crop data from database
    const { data: cropData, error } = await supabase
      .from('crop_dataset')
      .select('*');

    if (error) {
      console.error('Database error:', error);
      throw new Error('Failed to fetch crop data');
    }

    if (!cropData || cropData.length === 0) {
      throw new Error('No crop data available');
    }

    console.log(`Loaded ${cropData.length} crop records for ML prediction`);

    // Calculate similarity scores using Euclidean distance
    const recommendations = cropData.map(record => {
      const distance = Math.sqrt(
        Math.pow(input.nitrogen - record.nitrogen, 2) +
        Math.pow(input.phosphorus - record.phosphorus, 2) +
        Math.pow(input.potassium - record.potassium, 2) +
        Math.pow(input.temperature - record.temperature, 2) +
        Math.pow(input.humidity - record.humidity, 2) +
        Math.pow(input.ph - record.ph, 2) +
        Math.pow(input.rainfall - record.rainfall, 2)
      );

      return {
        crop: record.crop_label,
        distance,
        record
      };
    });

    // Group by crop and find best matches
    const cropGroups: { [key: string]: any[] } = {};
    recommendations.forEach(rec => {
      if (!cropGroups[rec.crop]) {
        cropGroups[rec.crop] = [];
      }
      cropGroups[rec.crop].push(rec);
    });

    // Calculate average distance for each crop and generate recommendations
    const cropScores = Object.entries(cropGroups).map(([crop, records]) => {
      const avgDistance = records.reduce((sum, r) => sum + r.distance, 0) / records.length;
      const minDistance = Math.min(...records.map(r => r.distance));
      
      // Convert distance to confidence (closer = higher confidence)
      const maxPossibleDistance = Math.sqrt(7 * Math.pow(100, 2)); // rough estimate
      const confidence = Math.max(0, (1 - minDistance / maxPossibleDistance)) * 100;
      
      // Generate reason based on closest match
      const closestMatch = records.find(r => r.distance === minDistance);
      const reason = generateReason(input, closestMatch.record);

      return {
        crop,
        confidence: Math.round(confidence),
        avgDistance,
        reason
      };
    });

    // Sort by confidence and take top 3
    const topRecommendations = cropScores
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 3);

    // Get market prices for recommended crops
    const { data: marketPrices } = await supabase
      .from('market_prices')
      .select('*')
      .in('crop_name', topRecommendations.map(r => r.crop))
      .order('price_date', { ascending: false });

    // Add market prices to recommendations
    const finalRecommendations: CropRecommendation[] = topRecommendations.map(rec => {
      const priceData = marketPrices?.find(p => p.crop_name.toLowerCase() === rec.crop.toLowerCase());
      return {
        crop: rec.crop,
        confidence: rec.confidence,
        reason: rec.reason,
        marketPrice: priceData?.price_per_kg
      };
    });

    console.log('Generated recommendations:', finalRecommendations);

    return new Response(
      JSON.stringify({ recommendations: finalRecommendations }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in ml-predict function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

function generateReason(input: CropInput, match: any): string {
  const factors = [];
  
  if (Math.abs(input.nitrogen - match.nitrogen) < 10) {
    factors.push('optimal nitrogen levels');
  }
  if (Math.abs(input.phosphorus - match.phosphorus) < 10) {
    factors.push('suitable phosphorus content');
  }
  if (Math.abs(input.potassium - match.potassium) < 10) {
    factors.push('appropriate potassium levels');
  }
  if (Math.abs(input.temperature - match.temperature) < 3) {
    factors.push('ideal temperature range');
  }
  if (Math.abs(input.humidity - match.humidity) < 5) {
    factors.push('optimal humidity conditions');
  }
  if (Math.abs(input.ph - match.ph) < 0.5) {
    factors.push('suitable soil pH');
  }
  if (Math.abs(input.rainfall - match.rainfall) < 50) {
    factors.push('adequate rainfall');
  }

  if (factors.length === 0) {
    return 'Based on similar environmental conditions in our dataset';
  }

  return `Recommended due to ${factors.slice(0, 2).join(' and ')}`;
}