import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Updating market prices...');

    // Simulate fetching live market prices from external API
    // In a real implementation, you would call actual market data APIs
    const marketUpdates = [
      { 
        crop_name: 'rice', 
        price_per_kg: 1.45 + (Math.random() * 0.3), // Simulate price variation
        market_location: 'Global Average'
      },
      { 
        crop_name: 'wheat', 
        price_per_kg: 0.80 + (Math.random() * 0.2),
        market_location: 'Global Average'
      },
      { 
        crop_name: 'maize', 
        price_per_kg: 0.65 + (Math.random() * 0.15),
        market_location: 'Global Average'
      },
      { 
        crop_name: 'cotton', 
        price_per_kg: 3.00 + (Math.random() * 0.5),
        market_location: 'Global Average'
      },
      { 
        crop_name: 'chickpea', 
        price_per_kg: 2.20 + (Math.random() * 0.4),
        market_location: 'Global Average'
      },
      { 
        crop_name: 'banana', 
        price_per_kg: 1.80 + (Math.random() * 0.3),
        market_location: 'Global Average'
      },
      { 
        crop_name: 'coffee', 
        price_per_kg: 8.50 + (Math.random() * 1.5),
        market_location: 'Global Average'
      },
    ];

    // Update prices in database
    for (const update of marketUpdates) {
      const { error } = await supabase
        .from('market_prices')
        .upsert({
          crop_name: update.crop_name,
          price_per_kg: Math.round(update.price_per_kg * 100) / 100, // Round to 2 decimals
          currency: 'USD',
          market_location: update.market_location,
          price_date: new Date().toISOString().split('T')[0], // Today's date
        }, {
          onConflict: 'crop_name,price_date'
        });

      if (error) {
        console.error(`Error updating ${update.crop_name}:`, error);
      } else {
        console.log(`Updated ${update.crop_name}: $${update.price_per_kg}/kg`);
      }
    }

    console.log('Market prices updated successfully');

    return new Response(
      JSON.stringify({ 
        message: 'Market prices updated successfully',
        updates: marketUpdates.length,
        timestamp: new Date().toISOString()
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in update-market-prices function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});