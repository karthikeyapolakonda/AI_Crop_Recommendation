import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Starting dataset loading...');

    // Check if data already exists
    const { count } = await supabase
      .from('crop_dataset')
      .select('*', { count: 'exact', head: true });

    if (count && count > 0) {
      console.log(`Dataset already loaded with ${count} records`);
      return new Response(
        JSON.stringify({ message: `Dataset already loaded with ${count} records`, count }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch CSV data from your file
    const csvResponse = await fetch('https://ansghzbqyauxrrmizvax.supabase.co/storage/v1/object/public/files/crop_dataset.csv');
    
    if (!csvResponse.ok) {
      // If file doesn't exist in storage, we'll create sample data
      console.log('CSV file not found in storage, creating sample data...');
      await createSampleData(supabase);
      return new Response(
        JSON.stringify({ message: 'Sample dataset created successfully', count: 100 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const csvText = await csvResponse.text();
    const lines = csvText.split('\n');
    const header = lines[0].split(',');
    
    console.log('CSV header:', header);

    const records = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      const values = line.split(',');
      if (values.length >= 8) {
        records.push({
          nitrogen: parseFloat(values[0]),
          phosphorus: parseFloat(values[1]),
          potassium: parseFloat(values[2]),
          temperature: parseFloat(values[3]),
          humidity: parseFloat(values[4]),
          ph: parseFloat(values[5]),
          rainfall: parseFloat(values[6]),
          crop_label: values[7].trim()
        });
      }
    }

    console.log(`Parsed ${records.length} records from CSV`);

    // Insert data in batches
    const batchSize = 1000;
    let totalInserted = 0;
    
    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      const { error } = await supabase
        .from('crop_dataset')
        .insert(batch);
      
      if (error) {
        console.error('Batch insert error:', error);
        throw error;
      }
      
      totalInserted += batch.length;
      console.log(`Inserted batch: ${totalInserted}/${records.length}`);
    }

    console.log('Dataset loading completed successfully');

    return new Response(
      JSON.stringify({ message: 'Dataset loaded successfully', count: totalInserted }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in load-dataset function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function createSampleData(supabase: any) {
  const sampleData = [
    // Rice samples
    { nitrogen: 90, phosphorus: 42, potassium: 43, temperature: 20.9, humidity: 82.0, ph: 6.5, rainfall: 202.9, crop_label: 'rice' },
    { nitrogen: 85, phosphorus: 58, potassium: 41, temperature: 21.8, humidity: 80.3, ph: 7.0, rainfall: 226.7, crop_label: 'rice' },
    { nitrogen: 60, phosphorus: 55, potassium: 44, temperature: 23.0, humidity: 82.3, ph: 7.8, rainfall: 263.9, crop_label: 'rice' },
    
    // Wheat samples
    { nitrogen: 20, phosphorus: 25, potassium: 20, temperature: 22.5, humidity: 60.0, ph: 6.8, rainfall: 150.0, crop_label: 'wheat' },
    { nitrogen: 25, phosphorus: 30, potassium: 25, temperature: 23.0, humidity: 58.5, ph: 7.2, rainfall: 160.5, crop_label: 'wheat' },
    { nitrogen: 22, phosphorus: 28, potassium: 22, temperature: 21.8, humidity: 62.0, ph: 6.9, rainfall: 145.0, crop_label: 'wheat' },
    
    // Maize samples
    { nitrogen: 80, phosphorus: 40, potassium: 20, temperature: 27.0, humidity: 65.0, ph: 6.0, rainfall: 100.0, crop_label: 'maize' },
    { nitrogen: 85, phosphorus: 45, potassium: 25, temperature: 28.5, humidity: 63.0, ph: 6.2, rainfall: 110.0, crop_label: 'maize' },
    { nitrogen: 75, phosphorus: 38, potassium: 18, temperature: 26.5, humidity: 67.0, ph: 5.8, rainfall: 95.0, crop_label: 'maize' },
    
    // Cotton samples
    { nitrogen: 120, phosphorus: 40, potassium: 25, temperature: 25.0, humidity: 70.0, ph: 7.5, rainfall: 80.0, crop_label: 'cotton' },
    { nitrogen: 115, phosphorus: 42, potassium: 28, temperature: 26.0, humidity: 68.0, ph: 7.8, rainfall: 85.0, crop_label: 'cotton' },
    { nitrogen: 125, phosphorus: 38, potassium: 22, temperature: 24.5, humidity: 72.0, ph: 7.2, rainfall: 75.0, crop_label: 'cotton' },
  ];

  const { error } = await supabase
    .from('crop_dataset')
    .insert(sampleData);

  if (error) {
    throw error;
  }

  // Also add sample market prices
  const marketPrices = [
    { crop_name: 'rice', price_per_kg: 1.50, currency: 'USD', market_location: 'Global Average' },
    { crop_name: 'wheat', price_per_kg: 0.85, currency: 'USD', market_location: 'Global Average' },
    { crop_name: 'maize', price_per_kg: 0.70, currency: 'USD', market_location: 'Global Average' },
    { crop_name: 'cotton', price_per_kg: 3.20, currency: 'USD', market_location: 'Global Average' },
  ];

  await supabase
    .from('market_prices')
    .insert(marketPrices);
}