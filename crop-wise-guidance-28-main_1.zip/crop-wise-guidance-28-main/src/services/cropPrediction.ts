// Crop Prediction Service
// Since we can't run Python models directly in the browser,
// we'll create a smart rule-based system using the crop data patterns

export interface CropInput {
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  temperature: number;
  humidity: number;
  ph: number;
  rainfall: number;
}

export interface CropRecommendation {
  crop: string;
  confidence: number;
  reasons: string[];
  icon: string;
  color: string;
  marketPrice?: number;
}

// Crop characteristics based on the dataset analysis
const cropProfiles = {
  rice: {
    nitrogen: { min: 60, max: 99, optimal: 80 },
    phosphorus: { min: 35, max: 60, optimal: 48 },
    potassium: { min: 35, max: 45, optimal: 40 },
    temperature: { min: 20, max: 27, optimal: 23 },
    humidity: { min: 80, max: 85, optimal: 82 },
    ph: { min: 5.0, max: 7.8, optimal: 6.5 },
    rainfall: { min: 180, max: 300, optimal: 240 },
    icon: "🌾",
    color: "text-amber-600"
  },
  maize: {
    nitrogen: { min: 70, max: 120, optimal: 95 },
    phosphorus: { min: 35, max: 65, optimal: 50 },
    potassium: { min: 15, max: 45, optimal: 30 },
    temperature: { min: 18, max: 27, optimal: 22 },
    humidity: { min: 55, max: 75, optimal: 65 },
    ph: { min: 5.5, max: 7.5, optimal: 6.5 },
    rainfall: { min: 60, max: 110, optimal: 85 },
    icon: "🌽",
    color: "text-yellow-600"
  },
  chickpea: {
    nitrogen: { min: 10, max: 50, optimal: 30 },
    phosphorus: { min: 60, max: 85, optimal: 72 },
    potassium: { min: 75, max: 120, optimal: 97 },
    temperature: { min: 17, max: 25, optimal: 21 },
    humidity: { min: 10, max: 20, optimal: 15 },
    ph: { min: 6.0, max: 7.5, optimal: 6.8 },
    rainfall: { min: 200, max: 300, optimal: 250 },
    icon: "🫘",
    color: "text-amber-700"
  },
  banana: {
    nitrogen: { min: 80, max: 120, optimal: 100 },
    phosphorus: { min: 70, max: 95, optimal: 82 },
    potassium: { min: 45, max: 55, optimal: 50 },
    temperature: { min: 25, max: 30, optimal: 27 },
    humidity: { min: 75, max: 85, optimal: 80 },
    ph: { min: 5.5, max: 6.5, optimal: 6.0 },
    rainfall: { min: 90, max: 120, optimal: 105 },
    icon: "🍌",
    color: "text-yellow-500"
  },
  coffee: {
    nitrogen: { min: 80, max: 120, optimal: 100 },
    phosphorus: { min: 15, max: 40, optimal: 28 },
    potassium: { min: 25, max: 35, optimal: 30 },
    temperature: { min: 23, max: 28, optimal: 25 },
    humidity: { min: 50, max: 70, optimal: 60 },
    ph: { min: 6.0, max: 7.5, optimal: 6.8 },
    rainfall: { min: 115, max: 200, optimal: 157 },
    icon: "☕",
    color: "text-amber-800"
  },
  cotton: {
    nitrogen: { min: 110, max: 160, optimal: 135 },
    phosphorus: { min: 40, max: 70, optimal: 55 },
    potassium: { min: 180, max: 220, optimal: 200 },
    temperature: { min: 21, max: 30, optimal: 25 },
    humidity: { min: 75, max: 85, optimal: 80 },
    ph: { min: 5.8, max: 8.0, optimal: 6.8 },
    rainfall: { min: 50, max: 100, optimal: 75 },
    icon: "🌿",
    color: "text-white"
  }
};

function calculateSuitabilityScore(input: CropInput, profile: any): number {
  const factors = [
    'nitrogen', 'phosphorus', 'potassium', 'temperature', 'humidity', 'ph', 'rainfall'
  ];
  
  let totalScore = 0;
  
  factors.forEach(factor => {
    const value = input[factor as keyof CropInput];
    const { min, max, optimal } = profile[factor];
    
    if (value >= min && value <= max) {
      // Calculate how close the value is to optimal
      const distance = Math.abs(value - optimal);
      const range = max - min;
      const score = Math.max(0, 1 - (distance / range));
      totalScore += score;
    }
  });
  
  return (totalScore / factors.length) * 100;
}

function generateReasons(input: CropInput, profile: any, cropName: string): string[] {
  const reasons: string[] = [];
  
  // Check NPK levels
  if (input.nitrogen >= profile.nitrogen.min && input.nitrogen <= profile.nitrogen.max) {
    reasons.push(`Nitrogen levels (${input.nitrogen}) are suitable for ${cropName}`);
  }
  
  if (input.phosphorus >= profile.phosphorus.min && input.phosphorus <= profile.phosphorus.max) {
    reasons.push(`Phosphorus content (${input.phosphorus}) supports good ${cropName} growth`);
  }
  
  if (input.potassium >= profile.potassium.min && input.potassium <= profile.potassium.max) {
    reasons.push(`Potassium levels (${input.potassium}) are optimal for ${cropName}`);
  }
  
  // Check environmental conditions
  if (input.temperature >= profile.temperature.min && input.temperature <= profile.temperature.max) {
    reasons.push(`Temperature (${input.temperature}°C) is ideal for ${cropName} cultivation`);
  }
  
  if (input.humidity >= profile.humidity.min && input.humidity <= profile.humidity.max) {
    reasons.push(`Humidity levels (${input.humidity}%) create favorable conditions`);
  }
  
  if (input.ph >= profile.ph.min && input.ph <= profile.ph.max) {
    reasons.push(`Soil pH (${input.ph}) is within the optimal range`);
  }
  
  if (input.rainfall >= profile.rainfall.min && input.rainfall <= profile.rainfall.max) {
    reasons.push(`Rainfall (${input.rainfall}mm) meets water requirements`);
  }
  
  return reasons.slice(0, 3); // Return top 3 reasons
}

export async function predictCrop(input: CropInput): Promise<CropRecommendation[]> {
  try {
    // Call the ML prediction edge function
    const response = await fetch('https://ansghzbqyauxrrmizvax.supabase.co/functions/v1/ml-predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ input })
    });

    if (!response.ok) {
      throw new Error('ML prediction failed');
    }

    const { recommendations } = await response.json();
    
    return recommendations.map((rec: any) => ({
      crop: rec.crop.charAt(0).toUpperCase() + rec.crop.slice(1),
      confidence: rec.confidence,
      reasons: [rec.reason],
      icon: getCropIcon(rec.crop),
      color: getCropColor(rec.crop),
      marketPrice: rec.marketPrice
    }));
    
  } catch (error) {
    console.error('ML prediction failed, using fallback:', error);
    
    // Fallback to rule-based system
    const recommendations: CropRecommendation[] = [];
    
    Object.entries(cropProfiles).forEach(([cropName, profile]) => {
      const confidence = calculateSuitabilityScore(input, profile);
      
      if (confidence > 20) {
        const reasons = generateReasons(input, profile, cropName);
        
        recommendations.push({
          crop: cropName,
          confidence: Math.round(confidence),
          reasons,
          icon: profile.icon,
          color: profile.color
        });
      }
    });
    
    return recommendations
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 3);
  }
}

function getCropIcon(crop: string): string {
  const icons: { [key: string]: string } = {
    rice: '🌾',
    wheat: '🌾',
    maize: '🌽',
    cotton: '🌿',
    chickpea: '🫘',
    banana: '🍌',
    coffee: '☕'
  };
  return icons[crop.toLowerCase()] || '🌱';
}

function getCropColor(crop: string): string {
  const colors: { [key: string]: string } = {
    rice: 'text-green-600',
    wheat: 'text-yellow-600',
    maize: 'text-orange-600',
    cotton: 'text-blue-600',
    chickpea: 'text-purple-600',
    banana: 'text-yellow-500',
    coffee: 'text-amber-600'
  };
  return colors[crop.toLowerCase()] || 'text-green-600';
}

export function validateInput(input: Partial<CropInput>): string[] {
  const errors: string[] = [];
  
  if (!input.nitrogen || input.nitrogen < 0 || input.nitrogen > 200) {
    errors.push('Nitrogen should be between 0-200 kg/ha');
  }
  
  if (!input.phosphorus || input.phosphorus < 0 || input.phosphorus > 150) {
    errors.push('Phosphorus should be between 0-150 kg/ha');
  }
  
  if (!input.potassium || input.potassium < 0 || input.potassium > 300) {
    errors.push('Potassium should be between 0-300 kg/ha');
  }
  
  if (!input.temperature || input.temperature < 0 || input.temperature > 50) {
    errors.push('Temperature should be between 0-50°C');
  }
  
  if (!input.humidity || input.humidity < 0 || input.humidity > 100) {
    errors.push('Humidity should be between 0-100%');
  }
  
  if (!input.ph || input.ph < 0 || input.ph > 14) {
    errors.push('pH should be between 0-14');
  }
  
  if (!input.rainfall || input.rainfall < 0 || input.rainfall > 500) {
    errors.push('Rainfall should be between 0-500mm');
  }
  
  return errors;
}