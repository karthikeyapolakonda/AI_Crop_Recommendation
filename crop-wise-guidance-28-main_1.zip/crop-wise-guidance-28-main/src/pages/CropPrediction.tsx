import CropPredictionForm from "@/components/CropPredictionForm";
import DatasetManager from "@/components/DatasetManager";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Database, TrendingUp, Zap } from "lucide-react";

export default function CropPrediction() {
  const features = [
    {
      icon: Brain,
      title: "AI Analysis",
      description: "Machine learning algorithms analyze soil and climate data",
      color: "text-blue-600"
    },
    {
      icon: Database,
      title: "Rich Dataset",
      description: "2000+ crop samples with comprehensive environmental data",
      color: "text-green-600"
    },
    {
      icon: TrendingUp,
      title: "High Accuracy",
      description: "95% prediction accuracy with confidence scoring",
      color: "text-purple-600"
    },
    {
      icon: Zap,
      title: "Instant Results",
      description: "Get recommendations in under 1 second",
      color: "text-orange-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-earth py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 px-4 py-2">
            <Brain className="w-4 h-4 mr-2" />
            AI-Powered Predictions
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Crop Recommendation System
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Enter your soil and environmental conditions to receive personalized crop recommendations 
            powered by machine learning algorithms trained on extensive agricultural datasets.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <Card key={index} className="text-center shadow-soft hover:shadow-glow transition-all duration-300 hover:scale-105">
              <CardContent className="pt-6">
                <div className="mx-auto w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Dataset Management */}
        <DatasetManager />

        {/* Main Prediction Form */}
        <CropPredictionForm />

        {/* Information Section */}
        <Card className="mt-12 shadow-soft">
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
            <CardDescription>
              Our AI system analyzes multiple environmental and soil factors
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  1
                </div>
                <h4 className="font-semibold mb-2">Input Parameters</h4>
                <p className="text-sm text-muted-foreground">
                  Enter soil nutrients (NPK), climate conditions, and environmental factors
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  2
                </div>
                <h4 className="font-semibold mb-2">AI Analysis</h4>
                <p className="text-sm text-muted-foreground">
                  Machine learning algorithms compare your data with optimal growing conditions
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  3
                </div>
                <h4 className="font-semibold mb-2">Get Recommendations</h4>
                <p className="text-sm text-muted-foreground">
                  Receive ranked crop suggestions with confidence scores and detailed explanations
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}