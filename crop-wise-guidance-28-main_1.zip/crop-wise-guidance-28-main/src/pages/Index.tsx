import HeroSection from "@/components/HeroSection";
import FeatureShowcase from "@/components/FeatureShowcase";
import CropPredictionForm from "@/components/CropPredictionForm";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Cloud, Brain, BarChart3 } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen">
      <HeroSection />
      
      <FeatureShowcase />
      
      <Separator className="my-0" />
      
      {/* Quick Links Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Explore AgriWisper Features</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Access comprehensive agricultural tools and insights to make informed farming decisions
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <Link to="/weather" className="group">
              <div className="p-6 rounded-lg bg-card border hover:shadow-glow transition-all duration-300 group-hover:scale-105 text-center">
                <Cloud className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Weather Monitoring</h3>
                <p className="text-muted-foreground mb-4">Real-time weather data and forecasts for agricultural planning</p>
                <Button variant="outline" className="group-hover:bg-primary group-hover:text-primary-foreground">
                  View Weather
                </Button>
              </div>
            </Link>
            
            <Link to="/prediction" className="group">
              <div className="p-6 rounded-lg bg-card border hover:shadow-glow transition-all duration-300 group-hover:scale-105 text-center">
                <Brain className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Crop Prediction</h3>
                <p className="text-muted-foreground mb-4">AI-powered crop recommendations based on soil and climate data</p>
                <Button variant="outline" className="group-hover:bg-primary group-hover:text-primary-foreground">
                  Get Predictions
                </Button>
              </div>
            </Link>
            
            <Link to="/analytics" className="group">
              <div className="p-6 rounded-lg bg-card border hover:shadow-glow transition-all duration-300 group-hover:scale-105 text-center">
                <BarChart3 className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Analytics Dashboard</h3>
                <p className="text-muted-foreground mb-4">System performance metrics and agricultural insights</p>
                <Button variant="outline" className="group-hover:bg-primary group-hover:text-primary-foreground">
                  View Analytics
                </Button>
              </div>
            </Link>
          </div>
        </div>
      </section>
      
      <section id="crop-prediction" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Try Crop Prediction</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get instant crop recommendations by entering your soil and environmental conditions
            </p>
          </div>
          <CropPredictionForm />
        </div>
      </section>
      
      <footer className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold">AgriWisper</h3>
            <p className="text-primary-foreground/80 max-w-2xl mx-auto">
              Empowering farmers with AI-driven insights, weather monitoring, and crop recommendations for sustainable and profitable agriculture.
            </p>
            <div className="flex justify-center space-x-6 text-sm text-primary-foreground/60">
              <span>© 2024 AgriWisper</span>
              <span>•</span>
              <span>Powered by Machine Learning</span>
              <span>•</span>
              <span>Built with ❤️ for Farmers</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
