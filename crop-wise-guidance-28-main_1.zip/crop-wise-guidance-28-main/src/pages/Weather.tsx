import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  Wind, 
  Thermometer, 
  Droplets,
  Eye,
  Gauge
} from "lucide-react";
import { toast } from "sonner";

interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  pressure: number;
  visibility: number;
  condition: string;
  forecast: {
    day: string;
    temp: number;
    condition: string;
    icon: string;
  }[];
}

export default function Weather() {
  const [location, setLocation] = useState("New Delhi, India");
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);

  // Mock weather data for demonstration
  const fetchWeatherData = async () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const mockData: WeatherData = {
        location: location,
        temperature: 28,
        humidity: 65,
        rainfall: 2.5,
        windSpeed: 12,
        pressure: 1013,
        visibility: 8,
        condition: "Partly Cloudy",
        forecast: [
          { day: "Today", temp: 28, condition: "Partly Cloudy", icon: "⛅" },
          { day: "Tomorrow", temp: 30, condition: "Sunny", icon: "☀️" },
          { day: "Day 3", temp: 26, condition: "Rainy", icon: "🌧️" },
          { day: "Day 4", temp: 27, condition: "Cloudy", icon: "☁️" },
          { day: "Day 5", temp: 29, condition: "Sunny", icon: "☀️" }
        ]
      };
      
      setWeatherData(mockData);
      setLoading(false);
      toast.success("Weather data updated successfully!");
    }, 1000);
  };

  useEffect(() => {
    fetchWeatherData();
  }, []);

  const weatherMetrics = [
    { 
      label: "Temperature", 
      value: `${weatherData?.temperature || 0}°C`, 
      icon: Thermometer, 
      color: "text-red-500",
      bg: "bg-red-50"
    },
    { 
      label: "Humidity", 
      value: `${weatherData?.humidity || 0}%`, 
      icon: Droplets, 
      color: "text-blue-500",
      bg: "bg-blue-50"
    },
    { 
      label: "Rainfall", 
      value: `${weatherData?.rainfall || 0}mm`, 
      icon: CloudRain, 
      color: "text-sky-500",
      bg: "bg-sky-50"
    },
    { 
      label: "Wind Speed", 
      value: `${weatherData?.windSpeed || 0} km/h`, 
      icon: Wind, 
      color: "text-green-500",
      bg: "bg-green-50"
    },
    { 
      label: "Pressure", 
      value: `${weatherData?.pressure || 0} hPa`, 
      icon: Gauge, 
      color: "text-purple-500",
      bg: "bg-purple-50"
    },
    { 
      label: "Visibility", 
      value: `${weatherData?.visibility || 0} km`, 
      icon: Eye, 
      color: "text-orange-500",
      bg: "bg-orange-50"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-earth py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">Agricultural Weather</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Real-time weather data and forecasts for informed farming decisions
          </p>
        </div>

        {/* Location Input */}
        <Card className="max-w-md mx-auto mb-8 shadow-soft">
          <CardHeader>
            <CardTitle className="text-lg">Location</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Enter location"
                className="flex-1"
              />
              <Button onClick={fetchWeatherData} disabled={loading} variant="hero">
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  "Update"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {weatherData && (
          <>
            {/* Current Weather */}
            <Card className="mb-8 shadow-soft hover:shadow-glow transition-all duration-300">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{weatherData.location}</CardTitle>
                <CardDescription className="text-lg">{weatherData.condition}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  {weatherMetrics.map((metric, index) => (
                    <div key={index} className={`p-4 rounded-lg ${metric.bg} hover:scale-105 transition-transform`}>
                      <div className="flex flex-col items-center text-center">
                        <metric.icon className={`w-8 h-8 ${metric.color} mb-2`} />
                        <div className="text-lg font-semibold">{metric.value}</div>
                        <div className="text-sm text-muted-foreground">{metric.label}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Forecast */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cloud className="w-6 h-6 text-primary" />
                  5-Day Forecast
                </CardTitle>
                <CardDescription>Weather outlook for agricultural planning</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {weatherData.forecast.map((day, index) => (
                    <Card key={index} className="text-center p-4 hover:shadow-glow transition-all duration-300 hover:scale-105">
                      <CardContent className="pt-4">
                        <div className="text-lg font-semibold mb-2">{day.day}</div>
                        <div className="text-3xl mb-2">{day.icon}</div>
                        <div className="text-xl font-bold text-primary mb-1">{day.temp}°C</div>
                        <div className="text-sm text-muted-foreground">{day.condition}</div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Agricultural Insights */}
            <Card className="mt-8 shadow-soft border-l-4 border-l-success">
              <CardHeader>
                <CardTitle className="text-success">🌱 Agricultural Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Crop Conditions</h4>
                    <p className="text-sm text-muted-foreground">
                      Current humidity ({weatherData.humidity}%) and temperature ({weatherData.temperature}°C) 
                      are ideal for rice and wheat cultivation.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Irrigation Advice</h4>
                    <p className="text-sm text-muted-foreground">
                      Recent rainfall of {weatherData.rainfall}mm reduces immediate irrigation needs. 
                      Monitor soil moisture levels.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}