import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, TrendingUp, Users, MapPin } from "lucide-react";

export default function Analytics() {
  const stats = [
    { label: "Total Predictions", value: "15,847", change: "+12%", icon: BarChart3 },
    { label: "Success Rate", value: "94.3%", change: "+2.1%", icon: TrendingUp },
    { label: "Active Users", value: "3,421", change: "+8%", icon: Users },
    { label: "Regions Covered", value: "156", change: "+5", icon: MapPin }
  ];

  const topCrops = [
    { crop: "Rice", predictions: 4832, percentage: 31, icon: "🌾" },
    { crop: "Wheat", predictions: 3421, percentage: 22, icon: "🌾" },
    { crop: "Maize", predictions: 2987, percentage: 19, icon: "🌽" },
    { crop: "Cotton", predictions: 2156, percentage: 14, icon: "🌿" },
    { crop: "Others", predictions: 2451, percentage: 14, icon: "🌱" }
  ];

  const recentActivity = [
    { user: "Farmer John", location: "Punjab, India", crop: "Rice", confidence: 94, time: "2 minutes ago" },
    { user: "Agricultural Co-op", location: "Iowa, USA", crop: "Maize", confidence: 87, time: "5 minutes ago" },
    { user: "Green Valley Farm", location: "Karnataka, India", crop: "Cotton", confidence: 91, time: "8 minutes ago" },
    { user: "Eco Farm Solutions", location: "California, USA", crop: "Wheat", confidence: 89, time: "12 minutes ago" },
    { user: "Sustainable Crops Ltd", location: "Queensland, Australia", crop: "Rice", confidence: 93, time: "15 minutes ago" }
  ];

  return (
    <div className="min-h-screen bg-gradient-earth py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 px-4 py-2">
            <BarChart3 className="w-4 h-4 mr-2" />
            Platform Analytics
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            System Performance & Usage
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Comprehensive analytics and insights into crop prediction system performance, 
            user engagement, and agricultural trends.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="shadow-soft hover:shadow-glow transition-all duration-300">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-sm text-success">{stat.change} from last month</p>
                  </div>
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Top Crops */}
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle>Most Recommended Crops</CardTitle>
              <CardDescription>Distribution of crop predictions this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topCrops.map((crop, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{crop.icon}</span>
                      <div>
                        <p className="font-medium">{crop.crop}</p>
                        <p className="text-sm text-muted-foreground">{crop.predictions} predictions</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{crop.percentage}%</p>
                      <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary transition-all duration-500"
                          style={{ width: `${crop.percentage}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle>Recent Predictions</CardTitle>
              <CardDescription>Latest crop recommendation activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                      <div>
                        <p className="font-medium text-sm">{activity.user}</p>
                        <p className="text-xs text-muted-foreground">{activity.location}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary" className="mb-1">
                        {activity.crop}
                      </Badge>
                      <p className="text-xs text-muted-foreground">{activity.confidence}% confidence</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Metrics */}
        <Card className="mt-8 shadow-soft">
          <CardHeader>
            <CardTitle>System Performance</CardTitle>
            <CardDescription>Key metrics and model accuracy statistics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-6 rounded-lg bg-gradient-primary text-white">
                <TrendingUp className="w-8 h-8 mx-auto mb-3" />
                <div className="text-3xl font-bold mb-2">94.3%</div>
                <div className="text-sm opacity-90">Model Accuracy</div>
              </div>
              <div className="text-center p-6 rounded-lg bg-success text-success-foreground">
                <BarChart3 className="w-8 h-8 mx-auto mb-3" />
                <div className="text-3xl font-bold mb-2">0.7s</div>
                <div className="text-sm opacity-90">Average Response Time</div>
              </div>
              <div className="text-center p-6 rounded-lg bg-warning text-warning-foreground">
                <Users className="w-8 h-8 mx-auto mb-3" />
                <div className="text-3xl font-bold mb-2">99.2%</div>
                <div className="text-sm opacity-90">User Satisfaction</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}