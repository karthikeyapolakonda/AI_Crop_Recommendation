import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Database, 
  Gauge, 
  Leaf, 
  MapPin, 
  TrendingUp,
  CheckCircle,
  BarChart3
} from "lucide-react";

export default function FeatureShowcase() {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Analysis",
      description: "Advanced machine learning algorithms analyze your soil and environmental data to provide accurate crop recommendations.",
      benefits: ["95% accuracy rate", "Data-driven insights", "Continuous learning"],
      color: "text-blue-600"
    },
    {
      icon: Database,
      title: "Comprehensive Database",
      description: "Built on extensive agricultural datasets with 2000+ crop samples and environmental conditions.",
      benefits: ["20+ crop varieties", "Global data coverage", "Regular updates"],
      color: "text-green-600"
    },
    {
      icon: Gauge,
      title: "Real-time Predictions",
      description: "Get instant crop recommendations with detailed confidence scores and reasoning.",
      benefits: ["Sub-second results", "Confidence scoring", "Detailed explanations"],
      color: "text-purple-600"
    },
    {
      icon: TrendingUp,
      title: "Yield Optimization",
      description: "Maximize your farm's productivity by choosing the most suitable crops for your conditions.",
      benefits: ["Increased yields", "Reduced waste", "Better ROI"],
      color: "text-orange-600"
    }
  ];

  const dataPoints = [
    { label: "Nitrogen (N)", description: "Essential for leaf growth and protein synthesis", icon: Leaf },
    { label: "Phosphorus (P)", description: "Critical for root development and energy transfer", icon: BarChart3 },
    { label: "Potassium (K)", description: "Improves disease resistance and water regulation", icon: CheckCircle },
    { label: "Temperature", description: "Affects growth rate and crop development", icon: Gauge },
    { label: "Humidity", description: "Influences plant water balance and disease risk", icon: MapPin },
    { label: "pH Level", description: "Determines nutrient availability in soil", icon: Database },
    { label: "Rainfall", description: "Primary water source for crop irrigation", icon: TrendingUp }
  ];

  return (
    <section className="py-20 bg-gradient-earth">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 px-4 py-2">
            <Brain className="w-4 h-4 mr-2" />
            Advanced Technology
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Intelligent Crop Selection Made Simple
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our platform combines cutting-edge AI with agricultural expertise to deliver 
            personalized crop recommendations for optimal farming success.
          </p>
        </div>

        {/* Main Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => (
            <Card key={index} className="shadow-soft hover:shadow-glow transition-all duration-300 hover:scale-105">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className={`p-2 rounded-lg bg-primary/10`}>
                    <feature.icon className={`w-6 h-6 ${feature.color}`} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </div>
                <CardDescription className="text-base">
                  {feature.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {feature.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      <span className="text-sm text-foreground">{benefit}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Data Points Section */}
        <Card className="shadow-soft">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl mb-2">
              7 Key Parameters Analyzed
            </CardTitle>
            <CardDescription>
              Our AI model considers multiple environmental and soil factors for accurate predictions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {dataPoints.map((point, index) => (
                <div key={index} className="flex items-start gap-3 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                  <point.icon className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-sm mb-1">{point.label}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{point.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}