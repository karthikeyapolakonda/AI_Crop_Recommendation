import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Database, TrendingUp, Loader2, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function DatasetManager() {
  const [isLoadingDataset, setIsLoadingDataset] = useState(false);
  const [isUpdatingPrices, setIsUpdatingPrices] = useState(false);
  const [datasetStatus, setDatasetStatus] = useState<'unknown' | 'loaded' | 'empty'>('unknown');
  const [lastPriceUpdate, setLastPriceUpdate] = useState<string | null>(null);

  const loadDataset = async () => {
    setIsLoadingDataset(true);
    try {
      const response = await fetch('https://ansghzbqyauxrrmizvax.supabase.co/functions/v1/load-dataset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error('Failed to load dataset');
      }

      const result = await response.json();
      toast.success(result.message);
      setDatasetStatus('loaded');
    } catch (error) {
      toast.error('Failed to load dataset. Please try again.');
      console.error('Dataset loading error:', error);
    } finally {
      setIsLoadingDataset(false);
    }
  };

  const updateMarketPrices = async () => {
    setIsUpdatingPrices(true);
    try {
      const response = await fetch('https://ansghzbqyauxrrmizvax.supabase.co/functions/v1/update-market-prices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error('Failed to update market prices');
      }

      const result = await response.json();
      toast.success('Market prices updated successfully!');
      setLastPriceUpdate(new Date().toLocaleString());
    } catch (error) {
      toast.error('Failed to update market prices. Please try again.');
      console.error('Price update error:', error);
    } finally {
      setIsUpdatingPrices(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-primary" />
            ML Dataset
          </CardTitle>
          <CardDescription>
            Load the crop recommendation dataset for machine learning predictions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Dataset Status:</span>
            <Badge variant={datasetStatus === 'loaded' ? 'default' : 'secondary'}>
              {datasetStatus === 'loaded' ? (
                <>
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Loaded
                </>
              ) : datasetStatus === 'empty' ? (
                'Empty'
              ) : (
                'Unknown'
              )}
            </Badge>
          </div>
          
          <Button 
            onClick={loadDataset}
            disabled={isLoadingDataset}
            className="w-full"
          >
            {isLoadingDataset ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Loading Dataset...
              </>
            ) : (
              <>
                <Database className="w-4 h-4 mr-2" />
                Load Dataset
              </>
            )}
          </Button>
          
          <p className="text-xs text-muted-foreground">
            This will load the crop cultivation dataset containing 2000+ samples for accurate ML predictions.
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Market Prices
          </CardTitle>
          <CardDescription>
            Update live market prices for crop recommendations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Last Update:</span>
            <Badge variant="outline">
              {lastPriceUpdate || 'Never'}
            </Badge>
          </div>
          
          <Button 
            onClick={updateMarketPrices}
            disabled={isUpdatingPrices}
            variant="outline"
            className="w-full"
          >
            {isUpdatingPrices ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Updating Prices...
              </>
            ) : (
              <>
                <TrendingUp className="w-4 h-4 mr-2" />
                Update Market Prices
              </>
            )}
          </Button>
          
          <p className="text-xs text-muted-foreground">
            Fetches current market prices for crops to provide economic insights with recommendations.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}