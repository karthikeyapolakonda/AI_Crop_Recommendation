import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Leaf, TrendingUp, Shield, Zap } from "lucide-react";
import heroImage from "@/assets/hero-agriculture.jpg";

export default function HeroSection() {
  const stats = [
    { icon: Leaf, label: "Crop Types", value: "20+", color: "text-green-600" },
    { icon: TrendingUp, label: "Accuracy", value: "95%", color: "text-blue-600" },
    { icon: Shield, label: "Success Rate", value: "98%", color: "text-purple-600" },
    { icon: Zap, label: "Analysis Speed", value: "<1s", color: "text-orange-600" }
  ];

  const scrollToPrediction = () => {
    const element = document.querySelector('#crop-prediction');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Agricultural landscape with diverse crops"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 via-primary/60 to-transparent" />
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center text-white">
          <Badge variant="secondary" className="mb-6 px-4 py-2 bg-white/10 text-white border-white/20 backdrop-blur-sm">
            <Leaf className="w-4 h-4 mr-2" />
            AI-Powered Agriculture
          </Badge>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            Smart Crop
            <span className="block bg-gradient-sunset bg-clip-text text-transparent">
              Recommendations
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto leading-relaxed">
            Harness the power of machine learning to optimize your farming decisions. 
            Get precise crop recommendations based on soil nutrients, climate, and environmental conditions.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              variant="hero" 
              size="lg" 
              onClick={scrollToPrediction}
              className="px-8 py-6 text-lg shadow-glow hover:scale-105 transition-all duration-300"
            >
              <Leaf className="w-5 h-5 mr-2" />
              Start Crop Analysis
            </Button>
            <Button 
              variant="earth" 
              size="lg"
              className="px-8 py-6 text-lg bg-white/10 border-white/30 text-white hover:bg-white hover:text-primary backdrop-blur-sm"
            >
              <TrendingUp className="w-5 h-5 mr-2" />
              View Success Stories
            </Button>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16">
            {stats.map((stat, index) => (
              <Card key={index} className="bg-white/10 border-white/20 backdrop-blur-sm hover:bg-white/20 transition-all duration-300 hover:scale-105">
                <CardContent className="pt-6 text-center">
                  <stat.icon className={`w-8 h-8 mx-auto mb-2 ${stat.color}`} />
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-white/80">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
      
      {/* Floating Animation Elements */}
      <div className="absolute top-20 left-10 w-16 h-16 bg-white/10 rounded-full blur-sm animate-float" style={{ animationDelay: '0s' }} />
      <div className="absolute top-40 right-20 w-12 h-12 bg-white/10 rounded-full blur-sm animate-float" style={{ animationDelay: '2s' }} />
      <div className="absolute bottom-40 left-20 w-20 h-20 bg-white/10 rounded-full blur-sm animate-float" style={{ animationDelay: '4s' }} />
    </section>
  );
}