import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Leaf, Thermometer, Droplets, Zap, TestTube, CloudRain } from "lucide-react";
import { predictCrop, validateInput, type CropInput, type CropRecommendation } from "@/services/cropPrediction";
import { toast } from "sonner";

export default function CropPredictionForm() {
  const [formData, setFormData] = useState<Partial<CropInput>>({
    nitrogen: 85,
    phosphorus: 42,
    potassium: 43,
    temperature: 24,
    humidity: 82,
    ph: 6.5,
    rainfall: 200
  });
  
  const [recommendations, setRecommendations] = useState<CropRecommendation[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof CropInput, value: string) => {
    const numValue = parseFloat(value);
    setFormData(prev => ({
      ...prev,
      [field]: isNaN(numValue) ? undefined : numValue
    }));
  };

  const handlePredict = async () => {
    const errors = validateInput(formData);
    
    if (errors.length > 0) {
      toast.error("Please correct the following errors: " + errors.join(", "));
      return;
    }

    setIsLoading(true);
    
    try {
      const results = await predictCrop(formData as CropInput);
      setRecommendations(results);
      
      if (results.length > 0) {
        toast.success(`Found ${results.length} suitable crop recommendation${results.length > 1 ? 's' : ''}!`);
      } else {
        toast.warning("No suitable crops found for these conditions. Try adjusting the parameters.");
      }
    } catch (error) {
      toast.error("Failed to generate recommendations. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const inputFields = [
    { key: 'nitrogen', label: 'Nitrogen (N)', unit: 'kg/ha', icon: Leaf, color: 'text-green-600' },
    { key: 'phosphorus', label: 'Phosphorus (P)', unit: 'kg/ha', icon: Zap, color: 'text-orange-600' },
    { key: 'potassium', label: 'Potassium (K)', unit: 'kg/ha', icon: TestTube, color: 'text-purple-600' },
    { key: 'temperature', label: 'Temperature', unit: '°C', icon: Thermometer, color: 'text-red-500' },
    { key: 'humidity', label: 'Humidity', unit: '%', icon: Droplets, color: 'text-blue-500' },
    { key: 'ph', label: 'pH Level', unit: '', icon: TestTube, color: 'text-indigo-600' },
    { key: 'rainfall', label: 'Rainfall', unit: 'mm', icon: CloudRain, color: 'text-sky-600' }
  ];

  return (
    <div className="space-y-8">
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Leaf className="w-6 h-6 text-primary" />
            Crop Recommendation System
          </CardTitle>
          <CardDescription>
            Enter your soil and environmental conditions to get AI-powered crop recommendations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {inputFields.map(({ key, label, unit, icon: Icon, color }) => (
              <div key={key} className="space-y-2">
                <Label htmlFor={key} className="flex items-center gap-2">
                  <Icon className={`w-4 h-4 ${color}`} />
                  {label}
                </Label>
                <div className="relative">
                  <Input
                    id={key}
                    type="number"
                    placeholder={`Enter ${label.toLowerCase()}`}
                    value={formData[key as keyof CropInput] || ''}
                    onChange={(e) => handleInputChange(key as keyof CropInput, e.target.value)}
                    className="transition-all duration-300 focus:shadow-soft"
                  />
                  {unit && (
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                      {unit}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <Separator />
          
          <div className="flex justify-center">
            <Button 
              onClick={handlePredict}
              disabled={isLoading}
              variant="hero"
              size="lg"
              className="px-8"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Leaf className="w-4 h-4" />
                  Get Crop Recommendations
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {recommendations.length > 0 && (
        <Card className="shadow-soft animate-float">
          <CardHeader>
            <CardTitle className="text-success">🎯 Recommended Crops</CardTitle>
            <CardDescription>
              Based on your soil and environmental conditions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {recommendations.map((rec, index) => (
                <Card key={rec.crop} className="border-l-4 border-l-primary hover:shadow-glow transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{rec.icon}</span>
                          <div>
                            <h3 className="text-lg font-semibold capitalize">{rec.crop}</h3>
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="bg-success/10 text-success-foreground">
                                {rec.confidence}% Match
                              </Badge>
                              {index === 0 && (
                                <Badge variant="default" className="bg-primary text-primary-foreground">
                                  Best Match
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <p className="text-sm font-medium text-muted-foreground">Why this crop?</p>
                          {rec.reasons.map((reason, idx) => (
                            <p key={idx} className="text-sm text-foreground flex items-start gap-2">
                              <span className="text-primary mt-1">•</span>
                              {reason}
                            </p>
                          ))}
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="w-16 h-16 rounded-full bg-gradient-primary flex items-center justify-center text-2xl shadow-glow">
                          {rec.icon}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}